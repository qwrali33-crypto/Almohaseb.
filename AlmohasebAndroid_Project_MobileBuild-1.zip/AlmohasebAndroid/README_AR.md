# المحاسب الذكي للمخبز — مشروع Android

هذا مشروع Android Studio يحوّل النسخة الحالية من برنامج المحاسب إلى تطبيق Android يستخدم WebView محلياً، ويحافظ على واجهة HTML ومنطق الحسابات والتخزين المحلي.

## بناء APK
1. ثبّت Android Studio على الكمبيوتر.
2. فك ضغط مجلد `AlmohasebAndroid.zip`.
3. افتح Android Studio ثم اختر **Open** وحدد مجلد `AlmohasebAndroid`.
4. انتظر Gradle Sync وثبّت Android SDK Platform 35 إذا طُلب منك.
5. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. بعد اكتمال البناء سيظهر خيار **locate** لمجلد APK. غالباً يكون في `app/build/outputs/apk/debug/app-debug.apk`.
7. انقل APK إلى هاتف Android وثبّته، مع السماح بالتثبيت من هذا المصدر عند الطلب.

## البيانات
- التطبيق يحتفظ بسجلاته محلياً على الهاتف عبر WebView LocalStorage.
- لتفادي فقدان بيانات النسخة القديمة في المتصفح: افتح النسخة القديمة، ادخل إلى السجلات واضغط **نسخة احتياطية**. انقل ملف JSON الناتج إلى الهاتف، ثم افتح التطبيق الجديد واختر **استعادة نسخة** وحدد الملف.
- تصدير CSV والنسخ الاحتياطي من التطبيق يحفظان الملفات في `Downloads/Almohaseb`.
- التطبيق لا يرفع بيانات الحسابات إلى خادم.

## ملاحظات
- هذه ملفات مشروع Android Studio وليست APK مبنياً بعد. يلزم Android Studio وAndroid SDK لإنتاج ملف APK النهائي.
- يعتمد التطبيق حالياً على نفس ملف HTML ووظائفه، ولم تُغيّر معادلات الحساب.

## بناء APK من الهاتف عبر GitHub Actions
أضيف ملف سير عمل في `.github/workflows/build.yml`.
1. أنشئ مستودع GitHub جديداً وارفع محتويات هذا المجلد إليه (وليس ملف ZIP نفسه).
2. افتح تبويب Actions في المستودع.
3. اختر Build Almohaseb APK ثم Run workflow.
4. بعد نجاح التشغيل، افتح التشغيل نفسه ونزّل artifact باسم `almohaseb-debug-apk`.
5. فك ضغط artifact وثبّت ملف APK على الهاتف.
